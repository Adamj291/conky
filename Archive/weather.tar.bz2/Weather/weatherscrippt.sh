#! /bin/bash

curl -s "wttr.in/HP2+6JZ_tQ_"=test.png > test.png 
&& 
convert test.png -transparent black weather.png 
&& 
rm test.png
